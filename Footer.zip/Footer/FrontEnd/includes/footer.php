<style>
.footer-area {
    padding: 20px; /* Adjust padding as needed */
}
.footer-logo-link {
    margin-right: 10px; /* Space between logos */
}</style>
<footer>
      <div class="footer-area footer-only">
        <div class="container">
          <div class="row section_gap">
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="single-footer-widget tp_widgets ">
                <h4 class="footer_title large_title">Description</h4>
                <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris. Vivamus hendrerit arcu sed erat molestie vehicula. Sed auctor neque eu tellus rhoncus ut eleifend nibh porttitor.
                </p>
              </div>
            </div>
            <div class="offset-lg-1 col-lg-2 col-md-6 col-sm-6">
              <div class="single-footer-widget tp_widgets">
                <h4 class="footer_title">Quick Links</h4>
                <ul class="list">
                  <li><a href="">Home</a></li>
                  <li><a href="">About</a></li>
                </ul>
              </div>
            </div>

            <div class="offset-lg-1 col-lg-3 col-md-6 col-sm-6">
              <div class="single-footer-widget tp_widgets">
                <h4 class="footer_title">Contact Us</h4>
                <div class="ml-40">
                  <p class="sm-head">
                    <span class="fa fa-user"></span>
                    Instructor
                  </p>
                  <p>Vince Mark E. Arnedo</p>
    
                  <p class="sm-head">
                    <span class="fa fa-envelope"></span>
                    Email
                  </p>
                  <p>
                   arnedovincemark@sjcbi.edu.ph<br>
                    
                  </p>
    
                  <p class="sm-head">
                    <span class="fa fa-location-arrow"></span>
                    Office
                  </p>
                  <p>
                  CICS Faculty, 4th Floor, Felicisimo Herrera Building<br>
                    
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="footer-bottom">
  <div class="container">
    <div class="row d-flex align-items-center">
      <div class="col-md-6 text-left">
        <p class="footer-text mb-0">
          Developed by BSIT CLASS OF 2025
        </p>
      </div>
      
      <div class="col-md-6 text-right">
        <div class="footer-logos">
          <a href="https://www.facebook.com/sjcbiofficial" class="footer-logo-link">
            <img src="FrontEnd/img/SJCB.png" alt="SJCB" width="40">
          </a>
          <a href="https://www.facebook.com/profile.php?id=61551530747411" class="footer-logo-link">
            <img src="FrontEnd/img/LITE.png" alt="LITE" width="40">
          </a>
          <a href="https://www.facebook.com/cicsjosefino" class="footer-logo-link">
            <img src="FrontEnd/img/CICS.png" alt="CICS" width="43">
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
    </footer>
